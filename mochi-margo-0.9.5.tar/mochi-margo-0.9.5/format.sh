#/bin/sh

clang-format -i src/margo-*.c
clang-format -i src/margo-*.h
clang-format -i include/*.h
