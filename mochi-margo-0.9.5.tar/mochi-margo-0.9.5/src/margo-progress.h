/*
 * (C) 2020 The University of Chicago
 *
 * See COPYRIGHT in top-level directory.
 */
#ifndef __MARGO_PROGRESS_H
#define __MARGO_PROGRESS_H

// progress function defined in margo-core.c
void __margo_hg_progress_fn(void* foo);

#endif
