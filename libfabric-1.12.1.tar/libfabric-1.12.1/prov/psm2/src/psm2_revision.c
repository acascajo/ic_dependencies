#ifndef PSMX2_IFS_VERSION
#define PSMX2_IFS_VERSION	""
#endif

#ifndef PSMX2_BUILD_TIMESTAMP
#define PSMX2_BUILD_TIMESTAMP	"<not available>"
#endif

#ifndef PSMX2_SRC_CHECKSUM
#define PSMX2_SRC_CHECKSUM	"<not available>"
#endif

#ifndef PSMX2_GIT_CHECKSUM
#define PSMX2_GIT_CHECKSUM	""
#endif

char psmi_hfi_IFS_version[] = PSMX2_IFS_VERSION;
char psmi_hfi_build_timestamp[] = PSMX2_BUILD_TIMESTAMP;
char psmi_hfi_sources_checksum[] = PSMX2_SRC_CHECKSUM;
char psmi_hfi_git_checksum[] = PSMX2_GIT_CHECKSUM;

