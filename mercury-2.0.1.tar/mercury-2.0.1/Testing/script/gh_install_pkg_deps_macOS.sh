#!/bin/bash
brew update
brew install mpich
